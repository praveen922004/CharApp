package com.example.prime.activities;

public class nameStore {
    public  static  String myname="";
}
